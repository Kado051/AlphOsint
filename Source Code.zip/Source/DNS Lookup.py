import os
import shutil
import importlib.util

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

DNS_ART = r"""
▓█████▄  ███▄    █   ██████     ██▓     ▒█████   ▒█████   ██ ▄█▀
▒██▀ ██▌ ██ ▀█   █ ▒██    ▒    ▓██▒    ▒██▒  ██▒▒██▒  ██▒ ██▄█▒ 
░██   █▌▓██  ▀█ ██▒░ ▓██▄      ▒██░    ▒██░  ██▒▒██░  ██▒▓███▄░ 
░▓█▄   ▌▓██▒  ▐▌██▒  ▒   ██▒   ▒██░    ▒██   ██░▒██   ██░▓██ █▄ 
░▒████▓ ▒██░   ▓██░▒██████▒▒   ░██████▒░ ████▓▒░░ ████▓▒░▒██▒ █▄
 ▒▒▓  ▒ ░ ▒░   ▒ ▒ ▒ ▒▓▒ ▒ ░   ░ ▒░▓  ░░ ▒░▒░▒░ ░ ▒░▒░▒░ ▒ ▒▒ ▓▒
 ░ ▒  ▒ ░ ░░   ░ ▒░░ ░▒  ░ ░   ░ ░ ▒  ░  ░ ▒ ▒░   ░ ▒ ▒░ ░ ░▒ ▒░
 ░ ░  ░    ░   ░ ░ ░  ░  ░       ░ ░   ░ ░ ░ ▒  ░ ░ ░ ▒  ░ ░░ ░ 
   ░             ░       ░         ░  ░    ░ ░      ░ ░    ░  ░ 
 ░                                                               
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("dns") is None:
        print("\n[*] dnspython module not found. Installing...")
        os.system("pip install dnspython")
        print("[+] Installation complete.\n")

def dns_lookup(domain):
    import dns.resolver
    print(f"\n[*] Fetching DNS records for '{domain}'...\n")
    
    record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA']
    
    for record in record_types:
        try:
            answers = dns.resolver.resolve(domain, record)
            print(f"[+] {record.ljust(5)} Records:")
            for rdata in answers:
                print(f"    - {rdata.to_text()}")
        except dns.resolver.NoAnswer:
            pass # Bu kayıt tipi yoksa es geç
        except dns.resolver.NXDOMAIN:
            print(f"[-] Domain '{domain}' does not exist.")
            return
        except Exception as e:
            pass # Diğer hataları es geç

def main():
    clear_screen()
    print_centered(DNS_ART)
    print()
    print()

    check_and_install_deps()

    domain = input("Search Domain: ").strip()
    
    if not domain:
        print("\n[!] Domain cannot be empty.")
        input()
        return

    # URL formatını temizle
    domain = domain.replace("http://", "").replace("https://", "").split("/")[0]

    dns_lookup(domain)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()