import os, shutil, platform, subprocess, importlib.util

def get_terminal_width(default=80):
    try: return shutil.get_terminal_size().columns
    except Exception: return default

PINGER_ART = r"""
 ██▓ ██▓███      ██▓███   ██▓ ███▄    █   ▄████ ▓█████  ██▀███  
▓██▒▓██░  ██▒   ▓██░  ██▒▓██▒ ██ ▀█   █  ██▒ ▀█▒▓█   ▀ ▓██ ▒ ██▒
▒██▒▓██░ ██▓▒   ▓██░ ██▓▒▒██▒▓██  ▀█ ██▒▒██░▄▄▄░▒███   ▓██ ░▄█ ▒
░██░▒██▄█▓▒ ▒   ▒██▄█▓▒ ▒░██░▓██▒  ▐▌██▒░▓█  ██▓▒▓█  ▄ ▒██▀▀█▄  
░██░▒██▒ ░  ░   ▒██▒ ░  ░░██░▒██░   ▓██░░▒▓███▀▒░▒████▒░██▓ ▒██▒
░▓  ▒▓▒░ ░  ░   ▒▓▒░ ░  ░░▓  ░ ▒░   ▒ ▒  ░▒   ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░
 ▒ ░░▒ ░        ░▒ ░      ▒ ░░ ░░   ░ ▒░  ░   ░  ░ ░  ░  ░▒ ░ ▒░
 ▒ ░░░          ░░        ▒ ░   ░   ░ ░ ░ ░   ░    ░     ░░   ░ 
 ░                        ░           ░       ░    ░  ░   ░     
"""

def print_centered(text, width=None):
    if width is None: width = get_terminal_width()
    for line in text.strip("\n").splitlines(): print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def ping_target(target):
    print(f"\n[*] Pinging '{target}'...\n")
    param = "-n" if platform.system().lower() == "windows" else "-c"
    try:
        result = subprocess.run(["ping", param, "4", target], capture_output=True, text=True, timeout=10)
        if result.returncode == 0: print(result.stdout)
        else:
            print("[-] Ping failed. Host might be down or blocking ICMP requests.")
            if result.stderr: print(f"[-] Details: {result.stderr.strip()}")
    except subprocess.TimeoutExpired: print("[-] Ping timed out.")
    except Exception as e: print(f"[!] Error: {e}")

def main():
    clear_screen(); print_centered(PINGER_ART); print(); print()
    target = input("Search IP / Domain: ").strip()
    if not target: print("\n[!] Target cannot be empty."); input(); return
    ping_target(target)
    print("\n"); input("Press ENTER to continue...")

if __name__ == "__main__": main()