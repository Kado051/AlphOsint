import os
import shutil
import importlib.util

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

# Senin verdiğin devasa EXIF Check tasarımı
CHECK_ART = r"""
▓█████ ▒██   ██▒ ██▓  █████▒    ▄████▄   ██░ ██ ▓█████  ▄████▄   ██ ▄█▀
▓█   ▀ ▒▒ █ █ ▒░▓██▒▓██   ▒    ▒██▀ ▀█  ▓██░ ██▒▓█   ▀ ▒██▀ ▀█   ██▄█▒ 
▒███   ░░  █   ░▒██▒▒████ ░    ▒▓█    ▄ ▒██▀▀██░▒███   ▒▓█    ▄ ▓███▄░ 
▒▓█  ▄  ░ █ █ ▒ ░██░░▓█▒  ░    ▒▓▓▄ ▄██▒░▓█ ░██ ▒▓█  ▄ ▒▓▓▄ ▄██▒▓██ █▄ 
░▒████▒▒██▒ ▒██▒░██░░▒█░       ▒ ▓███▀ ░░▓█▒░██▓░▒████▒▒ ▓███▀ ░▒██▒ █▄
░░ ▒░ ░▒▒ ░ ░▓ ░░▓   ▒ ░       ░ ░▒ ▒  ░ ▒ ░░▒░▒░░ ▒░ ░░ ░▒ ▒  ░▒ ▒▒ ▓▒
 ░ ░  ░░░   ░▒ ░ ▒ ░ ░           ░  ▒    ▒ ░▒░ ░ ░ ░  ░  ░  ▒   ░ ░▒ ▒░
   ░    ░    ░   ▒ ░ ░ ░       ░         ░  ░░ ░   ░   ░        ░ ░░ ░ 
   ░  ░ ░    ░   ░             ░ ░       ░  ░  ░   ░  ░░ ░      ░  ░   
                               ░                       ░            
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("exifread") is None:
        print("\n[*] exifread module not found. Installing...")
        os.system("pip install exifread")
        print("[+] Installation complete.\n")

def check_exif(file_path):
    import exifread
    print(f"\n[*] Checking EXIF data for '{file_path}'...\n")
    
    try:
        with open(file_path, 'rb') as f:
            tags = exifread.process_file(f)
            
            if not tags:
                print("[-] Status: NO EXIF data found.")
                print("[-] This image is likely stripped (social media, screenshot, etc.).")
            else:
                print("[+] Status: EXIF data FOUND.")
                
                make = tags.get('Image Make', 'N/A')
                model = tags.get('Image Model', 'N/A')
                date = tags.get('EXIF DateTimeOriginal', 'N/A')
                
                print(f"    - Device: {make} {model}")
                print(f"    - Date  : {date}")
                print(f"    - Total tags found: {len(tags)}")
                
    except Exception as e:
        print(f"\n[!] Error reading file: {e}")

def main():
    clear_screen()
    print_centered(CHECK_ART)
    print()
    print()

    check_and_install_deps()

    file_path = input("Enter image path: ").strip().strip('"')
    
    if not os.path.exists(file_path):
        print("\n[!] File not found.")
        input("Press ENTER to continue...")
        return

    check_exif(file_path)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()