import os, shutil, socket, concurrent.futures, importlib.util

def get_terminal_width(default=80):
    try: return shutil.get_terminal_size().columns
    except Exception: return default

PORT_ART = r"""
 ██▓███   ▒█████   ██▀███  ▄▄▄█████▓     ██████  ▄████▄   ▄▄▄       ███▄    █ 
▓██░  ██▒▒██▒  ██▒▓██ ▒ ██▒▓  ██▒ ▓▒   ▒██    ▒ ▒██▀ ▀█  ▒████▄     ██ ▀█   █ 
▓██░ ██▓▒▒██░  ██▒▓██ ░▄█ ▒▒ ▓██░ ▒░   ░ ▓██▄   ▒▓█    ▄ ▒██  ▀█▄  ▓██  ▀█ ██▒
▒██▄█▓▒ ▒▒██   ██░▒██▀▀█▄  ░ ▓██▓ ░      ▒   ██▒▒▓▓▄ ▄██▒░██▄▄▄▄██ ▓██▒  ▐▌██▒
▒██▒ ░  ░░ ████▓▒░░██▓ ▒██▒  ▒██▒ ░    ▒██████▒▒▒ ▓███▀ ░ ▓█   ▓██▒▒██░   ▓██░
▒▓▒░ ░  ░░ ▒░▒░▒░ ░ ▒▓ ░▒▓░  ▒ ░░      ▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░ ▒▒   ▓▒█░░ ▒░   ▒ ▒ 
░▒ ░       ░ ▒ ▒░   ░▒ ░ ▒░    ░       ░ ░▒  ░ ░  ░  ▒     ▒   ▒▒ ░░ ░░   ░ ▒░
░░       ░ ░ ░ ▒    ░░   ░   ░         ░  ░  ░  ░          ░   ▒      ░   ░ ░ 
             ░ ░     ░                       ░  ░ ░            ░  ░         ░ 
                                                ░                             
"""

def print_centered(text, width=None):
    if width is None: width = get_terminal_width()
    for line in text.strip("\n").splitlines(): print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("requests") is None: os.system("pip install requests")

def scan_port(ip, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.0)
            if s.connect_ex((ip, port)) == 0: return port
    except: pass
    return None

def get_service_name(port):
    services = {21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB", 1433: "MSSQL", 1521: "Oracle", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 8080: "HTTP-Proxy"}
    return services.get(port, "Unknown")

def scan_target(ip):
    print(f"\n[*] Scanning common ports on '{ip}'...\n")
    common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 1433, 1521, 3306, 3389, 5432, 8080]
    found_count = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(scan_port, ip, port): port for port in common_ports}
        for future in concurrent.futures.as_completed(futures):
            result_port = future.result()
            if result_port:
                service = get_service_name(result_port)
                print(f"[+] Port {str(result_port).ljust(5)} : {service.ljust(15)} (OPEN)")
                found_count += 1
    if found_count == 0: print("[-] No common open ports found.")
    else: print(f"\n[*] Total open ports found: {found_count}")

def main():
    clear_screen(); print_centered(PORT_ART); print(); print()
    check_and_install_deps()
    target = input("Search IP / Domain: ").strip()
    if not target: print("\n[!] Target cannot be empty."); input(); return
    try: ip = socket.gethostbyname(target)
    except socket.gaierror: print(f"\n[!] Could not resolve host: {target}"); input("Press ENTER..."); return
    print(f"\n[*] Target IP: {ip}")
    scan_target(ip)
    print("\n"); input("Press ENTER to continue...")

if __name__ == "__main__": main()