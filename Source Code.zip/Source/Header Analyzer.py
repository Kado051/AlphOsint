import os
import shutil
import requests
import importlib.util

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

# Senin verdiğin HEADER tasarımı
HEADER_ART = r"""
██░ ██ ▓█████ ▄▄▄      ▓█████▄ ▓█████  ██▀███  
▓██░ ██▒▓█   ▀▒████▄    ▒██▀ ██▌▓█   ▀ ▓██ ▒ ██▒
▒██▀▀██░▒███  ▒██  ▀█▄  ░██   █▌▒███   ▓██ ░▄█ ▒
░▓█ ░██ ▒▓█  ▄░██▄▄▄▄██ ░▓█▄   ▌▒▓█  ▄ ▒██▀▀█▄  
░▓█▒░██▓░▒████▒▓█   ▓██▒░▒████▓ ░▒████▒░██▓ ▒██▒
 ▒ ░░▒░▒░░ ▒░ ░▒▒   ▓▒█░ ▒▒▓  ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░
 ▒ ░▒░ ░ ░ ░  ░ ▒   ▒▒ ░ ░ ▒  ▒  ░ ░  ░  ░▒ ░ ▒░
 ░  ░░ ░   ░    ░   ▒    ░ ░  ░    ░     ░░   ░ 
 ░  ░  ░   ░  ░     ░  ░   ░       ░  ░   ░     
                         ░
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("requests") is None:
        print("\n[*] requests module not found. Installing...")
        os.system("pip install requests")
        print("[+] Installation complete.\n")

def analyze_headers(url):
    print(f"\n[*] Fetching HTTP Headers for '{url}'...\n")
    
    if not url.startswith("http"):
        url = "http://" + url
        
    try:
        # İstek at
        r = requests.get(url, timeout=10, allow_redirects=False)
        
        print(f"[+] Status Code : {r.status_code}")
        
        if r.status_code in [301, 302, 307, 308]:
            print(f"[+] Redirect    : {r.headers.get('Location', 'Unknown')}")
            print("[-] (Following redirect to fetch final headers...)\n")
            r = requests.get(url, timeout=10)
            print(f"[+] Final Status: {r.status_code}")
            
        headers = r.headers
        
        print("\n--- [ SERVER INFO ] ---")
        server = headers.get('Server', 'Not Disclosed')
        print(f"[+] Server      : {server}")
        
        powered_by = headers.get('X-Powered-By', 'Not Disclosed')
        print(f"[+] Powered By  : {powered_by}")
        
        # Cloudflare / CDN Kontrolü
        if 'cloudflare' in server.lower() or 'cf-ray' in headers:
            print("[+] CDN         : Cloudflare detected")
        elif 'akamai' in server.lower():
            print("[+] CDN         : Akamai detected")
        else:
            print("[+] CDN         : None or Unknown")

        print("\n--- [ SECURITY HEADERS ] ---")
        # HSTS
        hsts = headers.get('Strict-Transport-Security', 'MISSING')
        print(f"[+] HSTS        : {hsts}")
        
        # CSP
        csp = headers.get('Content-Security-Policy', 'MISSING')
        if len(csp) > 50: csp = csp[:47] + "..."
        print(f"[+] CSP         : {csp}")
        
        # X-Frame-Options
        xframe = headers.get('X-Frame-Options', 'MISSING')
        print(f"[+] X-Frame     : {xframe}")
        
        # X-XSS-Protection
        xxss = headers.get('X-XSS-Protection', 'MISSING')
        print(f"[+] X-XSS       : {xxss}")
        
        # CORS
        cors = headers.get('Access-Control-Allow-Origin', 'MISSING')
        print(f"[+] CORS        : {cors}")
        
    except requests.exceptions.SSLError:
        print("[-] SSL Error: Could not verify certificate.")
    except requests.exceptions.ConnectionError:
        print("[-] Connection Error: Host is down or blocking requests.")
    except Exception as e:
        print(f"[!] Error: {e}")

def main():
    clear_screen()
    print_centered(HEADER_ART)
    print()
    print()

    check_and_install_deps()

    target = input("Search URL / Domain: ").strip()
    
    if not target:
        print("\n[!] Target cannot be empty.")
        input()
        return

    analyze_headers(target)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()