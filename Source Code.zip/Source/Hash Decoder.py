import os
import shutil
import base64
import requests
import re
import binascii
import importlib.util

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

# Senin verdiğin HASH DECODER tasarımı
DECODER_ART = r"""
██░ ██  ▄▄▄        ██████  ██░ ██    ▓█████▄ ▓█████  ▄████▄   ▒█████  ▓█████▄ ▓█████  ██▀███  
▓██░ ██▒▒████▄    ▒██    ▒ ▓██░ ██▒   ▒██▀ ██▌▓█   ▀ ▒██▀ ▀█  ▒██▒  ██▒▒██▀ ██▌▓█   ▀ ▓██ ▒ ██▒
▒██▀▀██░▒██  ▀█▄  ░ ▓██▄   ▒██▀▀██░   ░██   █▌▒███   ▒▓█    ▄ ▒██░  ██▒░██   █▌▒███   ▓██ ░▄█ ▒
░▓█ ░██ ░██▄▄▄▄██   ▒   ██▒░▓█ ░██    ░▓█▄   ▌▒▓█  ▄ ▒▓▓▄ ▄██▒▒██   ██░░▓█▄   ▌▒▓█  ▄ ▒██▀▀█▄  
░▓█▒░██▓ ▓█   ▓██▒▒██████▒▒░▓█▒░██▓   ░▒████▓ ░▒████▒▒ ▓███▀ ░░ ████▓▒░░▒████▓ ░▒████▒░██▓ ▒██▒
 ▒ ░░▒░▒ ▒▒   ▓▒█░▒ ▒▓▒ ▒ ░ ▒ ░░▒░▒    ▒▒▓  ▒ ░░ ▒░ ░░ ░▒ ▒  ░░ ▒░▒░▒░  ▒▒▓  ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░
 ▒ ░▒░ ░  ▒   ▒▒ ░░ ░▒  ░ ░ ▒ ░▒░ ░    ░ ▒  ▒  ░ ░  ░  ░  ▒     ░ ▒ ▒░  ░ ▒  ▒  ░ ░  ░  ░▒ ░ ▒░
 ░  ░░ ░  ░   ▒   ░  ░  ░   ░  ░░ ░    ░ ░  ░    ░   ░        ░ ░ ░ ▒   ░ ░  ░    ░     ░░   ░ 
 ░  ░  ░      ░  ░      ░   ░  ░  ░      ░       ░  ░░ ░          ░ ░     ░       ░  ░   ░     
                                       ░             ░                  ░
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("requests") is None:
        print("\n[*] requests module not found. Installing...")
        os.system("pip install requests")
        print("[+] Installation complete.\n")

def identify_and_decode(text):
    text = text.strip()
    clean_text = text.replace(" ", "") # Boşlukları temizle (Hex için)
    
    # 1. Hash Kontrolü (MD5, SHA1, SHA256)
    if re.fullmatch(r'[a-fA-F0-9]{32}', text):
        print("[+] Type detected: MD5 Hash")
        search_hash(text, "md5")
    elif re.fullmatch(r'[a-fA-F0-9]{40}', text):
        print("[+] Type detected: SHA1 Hash")
        search_hash(text, "sha1")
    elif re.fullmatch(r'[a-fA-F0-9]{64}', text):
        print("[+] Type detected: SHA256 Hash")
        search_hash(text, "sha256")
        
    # 2. Hex Kontrolü (Örn: 68 65 6c 6c 6f)
    elif re.fullmatch(r'[a-fA-F0-9]+', clean_text) and len(clean_text) % 2 == 0:
        try:
            decoded_hex = bytes.fromhex(clean_text).decode('utf-8')
            print("[+] Type detected: Hex (ASCII)")
            print(f"[+] Decoded     : {decoded_hex}")
            return
        except Exception:
            pass # Eğer çözülemezse Base64 veya diğerlerini dene
            
    # 3. Binary Kontrolü (Örn: 01101000 01101001)
    if re.fullmatch(r'[01 ]+', text) and len(clean_text) % 8 == 0:
        try:
            decoded_bin = ''.join(chr(int(clean_text[i:i+8], 2)) for i in range(0, len(clean_text), 8))
            print("[+] Type detected: Binary")
            print(f"[+] Decoded     : {decoded_bin}")
            return
        except Exception:
            pass

    # 4. Base64 veya URL Decode
    try:
        decoded_bytes = base64.b64decode(text, validate=True)
        decoded_str = decoded_bytes.decode('utf-8')
        print("[+] Type detected: Base64")
        print(f"[+] Decoded     : {decoded_str}")
    except Exception:
        try:
            from urllib.parse import unquote
            decoded_url = unquote(text)
            if decoded_url != text:
                print("[+] Type detected: URL Encoded")
                print(f"[+] Decoded     : {decoded_url}")
            else:
                print("[-] Could not identify the input format (Not Base64, Hex, Binary or Hash).")
        except Exception:
            print("[-] Could not identify the input format.")

def search_hash(hash_value, hash_type):
    print(f"[*] Searching {hash_type.upper()} hash in databases...\n")
    try:
        url = f"https://nitrx-team.vercel.app/api/hash?query={hash_value}&type={hash_type}"
        r = requests.get(url, timeout=10)
        
        if r.status_code == 200:
            data = r.json()
            if data.get("status") == "success" and data.get("result"):
                print(f"[+] Hash Cracked : {data['result']}")
            else:
                print("[-] Hash not found in any known databases.")
        else:
            print(f"[-] API Error: {r.status_code}")
    except Exception as e:
        print(f"[!] Error searching hash: {e}")

def main():
    clear_screen()
    print_centered(DECODER_ART)
    print()
    print()

    check_and_install_deps()

    target = input("Enter Hash / Base64 / URL / Hex: ").strip()
    
    if not target:
        print("\n[!] Input cannot be empty.")
        input()
        return

    print()
    identify_and_decode(target)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()