import os
import shutil
import socket
import ssl
import requests
import importlib.util
from datetime import datetime

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

SSL_ART = r"""
 ██████  ██████  ██▓    
▒██    ▒ ▒██    ▒ ▓██▒    
░ ▓██▄   ░ ▓██▄   ▒██░    
  ▒   ██▒  ▒   ██▒▒██░    
▒██████▒▒▒██████▒▒░██████▒
▒ ▒▓▒ ▒ ░▒ ▒▓▒ ▒ ░░ ▒░▓  ░
░ ░▒  ░ ░░ ░▒  ░ ░░ ░ ▒  ░
░  ░  ░  ░  ░  ░    ░ ░   
      ░        ░      ░  ░
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("requests") is None:
        print("\n[*] requests module not found. Installing...")
        os.system("pip install requests")
        print("[+] Installation complete.\n")

def get_live_certificate(domain):
    print(f"\n[*] Fetching live SSL certificate for '{domain}'...\n")
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                
                # Subject (Kime ait)
                subject = dict(x[0] for x in cert['subject'])
                print(f"[+] Common Name  : {subject.get('commonName', 'N/A')}")
                
                # Issuer (Kim verdi)
                issuer = dict(x[0] for x in cert['issuer'])
                print(f"[+] Issuer       : {issuer.get('organizationName', 'N/A')}")
                print(f"[+] Issued By    : {issuer.get('commonName', 'N/A')}")
                
                # Tarihler
                print(f"[+] Valid From   : {cert['notBefore']}")
                print(f"[+] Valid Until  : {cert['notAfter']}")
                
                # Subject Alternative Names (SAN) - Gizli Alt Alan Adları
                sans = []
                for type, name in cert.get('subjectAltName', []):
                    if type == 'DNS':
                        sans.append(name)
                
                if sans:
                    print(f"\n[+] Subject Alt Names (SAN):")
                    for san in sans:
                        print(f"    - {san}")
                else:
                    print("\n[-] No Subject Alternative Names found.")
                    
    except ssl.SSLCertVerificationError:
        print("[-] SSL Certificate verification failed (Self-signed or expired).")
    except Exception as e:
        print(f"[!] Error fetching live certificate: {e}")

def get_historical_certs(domain):
    print(f"\n[*] Fetching historical certificates from crt.sh...\n")
    try:
        # crt.sh ücretsiz ve API anahtarı istemez
        url = f"https://crt.sh/?q=%.{domain}&output=json"
        r = requests.get(url, timeout=20)
        
        if r.status_code == 200:
            data = r.json()
            if not data:
                print("[-] No historical certificates found.")
                return
                
            # Sadece son 10 tanesini gösterelim (çok kalabalık olmasın)
            unique_subdomains = set()
            for cert in data[:50]: # Son 50 sertifikayı tara
                name_value = cert.get('name_value', '')
                for name in name_value.split('\n'):
                    name = name.strip().lower()
                    if name.endswith(f".{domain}") or name == domain:
                        unique_subdomains.add(name)
                        
            if unique_subdomains:
                print(f"[+] Found {len(unique_subdomains)} unique subdomains in history:")
                for sub in sorted(unique_subdomains):
                    print(f"    - {sub}")
            else:
                print("[-] No subdomains found in certificate history.")
        else:
            print(f"[-] crt.sh API Error: {r.status_code}")
    except Exception as e:
        print(f"[!] Error fetching historical data: {e}")

def main():
    clear_screen()
    print_centered(SSL_ART)
    print()
    print()

    check_and_install_deps()

    target = input("Search Domain: ").strip()
    
    if not target:
        print("\n[!] Domain cannot be empty.")
        input()
        return

    # URL formatını temizle
    target = target.replace("http://", "").replace("https://", "").split("/")[0]

    get_live_certificate(target)
    get_historical_certs(target)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()