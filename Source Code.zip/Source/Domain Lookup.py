import os, shutil, requests, socket, importlib.util

def get_terminal_width(default=80):
    try: return shutil.get_terminal_size().columns
    except Exception: return default

DOMAIN_ART = r"""
▓█████▄  ▒█████   ███▄ ▄███▓ ▄▄▄       ██▓ ███▄    █ 
▒██▀ ██▌▒██▒  ██▒▓██▒▀█▀ ██▒▒████▄    ▓██▒ ██ ▀█   █ 
░██   █▌▒██░  ██▒▓██    ▓██░▒██  ▀█▄  ▒██▒▓██  ▀█ ██▒
░▓█▄   ▌▒██   ██░▒██    ▒██ ░██▄▄▄▄██ ░██░▓██▒  ▐▌██▒
░▒████▓ ░ ████▓▒░▒██▒   ░██▒ ▓█   ▓██▒░██░▒██░   ▓██░
 ▒▒▓  ▒ ░ ▒░▒░▒░ ░ ▒░   ░  ░ ▒▒   ▓▒█░░▓  ░ ▒░   ▒ ▒ 
 ░ ▒  ▒   ░ ▒ ▒░ ░  ░      ░  ▒   ▒▒ ░ ▒ ░░ ░░   ░ ▒░
 ░ ░  ░ ░ ░ ░ ▒  ░      ░     ░   ▒    ▒ ░   ░   ░ ░ 
   ░        ░ ░         ░         ░  ░ ░           ░ 
 ░                                                   
"""

def print_centered(text, width=None):
    if width is None: width = get_terminal_width()
    for line in text.strip("\n").splitlines(): print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def clean_domain(input_string):
    domain = input_string.replace("http://", "").replace("https://", "")
    domain = domain.split("/")[0]
    if domain.startswith("www."): domain = domain[4:]
    return domain

def get_domain_info(domain):
    try: print(f"[+] IP Address   : {socket.gethostbyname(domain)}")
    except: print(f"[-] IP Address   : Could not resolve IP")
    try:
        response = requests.get(f"https://rdap.org/domain/{domain}", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"[+] Domain Name : {data.get('ldhName', domain)}")
            for entity in data.get("entities", []):
                if "registrar" in entity.get("roles", []):
                    vcard = entity.get("vcardArray", [])
                    if len(vcard) > 1:
                        for item in vcard[1]:
                            if item[0] == "fn": print(f"[+] Registrar   : {item[3]}")
            for event in data.get("events", []):
                if event.get("eventAction") == "registration": print(f"[+] Created     : {event.get('eventDate')[:10]}")
                if event.get("eventAction") == "expiration": print(f"[+] Expires     : {event.get('eventDate')[:10]}")
            ns = [n.get("ldhName") for n in data.get("nameservers", [])]
            if ns: print(f"[+] NameServers : {', '.join(ns)}")
        else: print(f"[-] WHOIS/RDAP data not found for {domain}.")
    except Exception as e: print(f"[!] Error: {e}")

def main():
    clear_screen(); print_centered(DOMAIN_ART); print(); print()
    target = input("Search Domain: ").strip()
    if not target: print("\n[!] Domain cannot be empty."); input(); return
    print(f"\n[*] Searching for '{target}'...\n")
    get_domain_info(clean_domain(target))
    print("\n"); input("Press ENTER to continue...")

if __name__ == "__main__": main()