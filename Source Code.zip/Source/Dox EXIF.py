import os
import shutil
import importlib.util

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

# Senin verdiğin devasa tasarım
EXIF_ART = r"""
▓█████▄  ▒█████  ▒██   ██▒   ▓█████ ▒██   ██▒ ██▓  █████▒
▒██▀ ██▌▒██▒  ██▒▒▒ █ █ ▒░   ▓█   ▀ ▒▒ █ █ ▒░▓██▒▓██   ▒ 
░██   █▌▒██░  ██▒░░  █   ░   ▒███   ░░  █   ░▒██▒▒████ ░ 
░▓█▄   ▌▒██   ██░ ░ █ █ ▒    ▒▓█  ▄  ░ █ █ ▒ ░██░░▓█▒  ░ 
░▒████▓ ░ ████▓▒░▒██▒ ▒██▒   ░▒████▒▒██▒ ▒██▒░██░░▒█░    
 ▒▒▓  ▒ ░ ▒░▒░▒░ ▒▒ ░ ░▓ ░   ░░ ▒░ ░▒▒ ░ ░▓ ░░▓   ▒ ░    
 ░ ▒  ▒   ░ ▒ ▒░ ░░   ░▒ ░    ░ ░  ░░░   ░▒ ░ ▒ ░ ░      
 ░ ░  ░ ░ ░ ░ ▒   ░    ░        ░    ░    ░   ▒ ░ ░ ░    
   ░        ░ ░   ░    ░        ░  ░ ░    ░   ░          
 ░                                                        
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("exifread") is None:
        print("\n[*] exifread module not found. Installing...")
        os.system("pip install exifread")
        print("[+] Installation complete.\n")

def convert_to_decimal(values):
    d = float(values[0].num) / float(values[0].den)
    m = float(values[1].num) / float(values[1].den)
    s = float(values[2].num) / float(values[2].den)
    return d + (m / 60.0) + (s / 3600.0)

def extract_exif(file_path):
    import exifread
    print(f"\n[*] Extracting EXIF data from '{file_path}'...\n")
    
    try:
        with open(file_path, 'rb') as f:
            tags = exifread.process_file(f)
            if not tags:
                print("[-] No EXIF data found in this image.")
                return

            make = tags.get('Image Make', 'Unknown')
            model = tags.get('Image Model', 'Unknown')
            date_taken = tags.get('EXIF DateTimeOriginal', 'Unknown')
            
            print(f"[+] Device Make  : {make}")
            print(f"[+] Device Model : {model}")
            print(f"[+] Date Taken   : {date_taken}")
            
            lat = tags.get('GPS GPSLatitude')
            lat_ref = tags.get('GPS GPSLatitudeRef')
            lon = tags.get('GPS GPSLongitude')
            lon_ref = tags.get('GPS GPSLongitudeRef')
            
            if lat and lon and lat_ref and lon_ref:
                lat_decimal = convert_to_decimal(lat.values)
                lon_decimal = convert_to_decimal(lon.values)
                
                if str(lat_ref) == 'S': lat_decimal = -lat_decimal
                if str(lon_ref) == 'W': lon_decimal = -lon_decimal
                
                print(f"\n[+] GPS Latitude  : {lat_decimal}")
                print(f"[+] GPS Longitude : {lon_decimal}")
                print(f"\n[+] Google Maps   : https://www.google.com/maps?q={lat_decimal},{lon_decimal}")
            else:
                print("\n[-] No GPS data found in this image.")
                
    except Exception as e:
        print(f"\n[!] Error reading EXIF data: {e}")

def main():
    clear_screen()
    print_centered(EXIF_ART)
    print()
    print()

    check_and_install_deps()

    file_path = input("Enter image path: ").strip().strip('"')
    
    if not os.path.exists(file_path):
        print("\n[!] File not found.")
        input("Press ENTER to continue...")
        return

    extract_exif(file_path)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()