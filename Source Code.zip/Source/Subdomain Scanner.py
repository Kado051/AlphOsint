import os, shutil, socket, concurrent.futures, importlib.util

def get_terminal_width(default=80):
    try: return shutil.get_terminal_size().columns
    except Exception: return default

SUBDOMAIN_ART = r"""
  ██████  █    ██  ▄▄▄▄   ▓█████▄  ▒█████   ███▄ ▄███▓ ▄▄▄       ██▓ ███▄    █ 
▒██    ▒  ██  ▓██▒▓█████▄ ▒██▀ ██▌▒██▒  ██▒▓██▒▀█▀ ██▒▒████▄    ▓██▒ ██ ▀█   █ 
░ ▓██▄   ▓██  ▒██░▒██▒ ▄██░██   █▌▒██░  ██▒▓██    ▓██░▒██  ▀█▄  ▒██▒▓██  ▀█ ██▒
  ▒   ██▒▓▓█  ░██░▒██░█▀  ░▓█▄   ▌▒██   ██░▒██    ▒██ ░██▄▄▄▄██ ░██░▓██▒  ▐▌██▒
▒██████▒▒▒▒█████▓ ░▓█  ▀█▓░▒████▓ ░ ████▓▒░▒██▒   ░██▒ ▓█   ▓██▒░██░▒██░   ▓██░
▒ ▒▓▒ ▒ ░░▒▓▒ ▒ ▒ ░▒▓███▀▒ ▒▒▓  ▒ ░ ▒░▒░▒░ ░ ▒░   ░  ░ ▒▒   ▓▒█░░▓  ░ ▒░   ▒ ▒ 
░ ░▒  ░ ░░░▒░ ░ ░ ▒░▒   ░  ░ ▒  ▒   ░ ▒ ▒░ ░  ░      ░  ▒   ▒▒ ░ ▒ ░░ ░░   ░ ▒░
░  ░  ░   ░░░ ░ ░  ░    ░  ░ ░  ░ ░ ░ ░ ▒  ░      ░     ░   ▒    ▒ ░   ░   ░ ░ 
      ░     ░      ░         ░        ░ ░         ░         ░  ░ ░           ░ 
                        ░  ░                                                   
"""

def print_centered(text, width=None):
    if width is None: width = get_terminal_width()
    for line in text.strip("\n").splitlines(): print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("requests") is None: os.system("pip install requests")

def check_subdomain(sub, domain):
    full_url = f"{sub}.{domain}"
    try:
        socket.gethostbyname(full_url)
        return full_url
    except socket.error: return None

def scan_subdomains(domain):
    print(f"\n[*] Scanning subdomains for '{domain}'...\n")
    common_subs = ["www", "mail", "ftp", "webmail", "smtp", "pop", "ns1", "ns2", "admin", "api", "dev", "test", "blog", "shop", "vpn", "m", "secure", "portal", "cpanel", "webdisk", "autodiscover", "cdn", "app", "support", "login", "dns", "remote", "help"]
    found_count = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
        futures = {executor.submit(check_subdomain, sub, domain): sub for sub in common_subs}
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result:
                print(f"[+] Found: https://{result}")
                found_count += 1
    if found_count == 0: print("[-] No common subdomains found.")
    else: print(f"\n[*] Total subdomains found: {found_count}")

def main():
    clear_screen(); print_centered(SUBDOMAIN_ART); print(); print()
    check_and_install_deps()
    domain = input("Search Domain: ").strip()
    if not domain: print("\n[!] Domain cannot be empty."); input(); return
    domain = domain.replace("http://", "").replace("https://", "").split("/")[0]
    if domain.startswith("www."): domain = domain[4:]
    print(f"\n[*] Scanning '{domain}'...\n")
    scan_subdomains(domain)
    print("\n"); input("Press ENTER to continue...")

if __name__ == "__main__": main()