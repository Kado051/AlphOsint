import os, shutil, requests, importlib.util

def get_terminal_width(default=80):
    try: return shutil.get_terminal_size().columns
    except Exception: return default

IP_ART = r"""
 ██▓ ██▓███       ██████ ▓█████ ▄▄▄       ██▀███   ▄████▄   ██░ ██ 
▓██▒▓██░  ██▒   ▒██    ▒ ▓█   ▀▒████▄    ▓██ ▒ ██▒▒██▀ ▀█  ▓██░ ██▒
▒██▒▓██░ ██▓▒   ░ ▓██▄   ▒███  ▒██  ▀█▄  ▓██ ░▄█ ▒▒▓█    ▄ ▒██▀▀██░
░██░▒██▄█▓▒ ▒     ▒   ██▒▒▓█  ▄░██▄▄▄▄██ ▒██▀▀█▄  ▒▓▓▄ ▄██▒░▓█ ░██ 
░██░▒██▒ ░  ░   ▒██████▒▒░▒████▒▓█   ▓██▒░██▓ ▒██▒▒ ▓███▀ ░░▓█▒░██▓
░▓  ▒▓▒░ ░  ░   ▒ ▒▓▒ ▒ ░░░ ▒░ ░▒▒   ▓▒█░░ ▒▓ ░▒▓░░ ░▒ ▒  ░ ▒ ░░▒░▒
 ▒ ░░▒ ░        ░ ░▒  ░ ░ ░ ░  ░ ▒   ▒▒ ░  ░▒ ░ ▒░  ░  ▒    ▒ ░▒░ ░
 ▒ ░░░          ░  ░  ░     ░    ░   ▒     ░░   ░ ░         ░  ░░ ░
 ░                    ░     ░  ░     ░  ░   ░     ░ ░       ░  ░  ░
"""

def print_centered(text, width=None):
    if width is None: width = get_terminal_width()
    for line in text.strip("\n").splitlines(): print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("requests") is None: os.system("pip install requests")

def get_ip_info(ip):
    try:
        response = requests.get(f"http://ip-api.com/json/{ip}", timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "success":
                print(f"[+] IP Address : {data.get('query')}")
                print(f"[+] Country    : {data.get('country')} ({data.get('countryCode')})")
                print(f"[+] Region     : {data.get('regionName')}")
                print(f"[+] City       : {data.get('city')}")
                print(f"[+] ISP        : {data.get('isp')}")
                print(f"[+] Org        : {data.get('org')}")
                print(f"[+] Timezone   : {data.get('timezone')}")
                return True
            else: print("[-] Invalid IP or not found.")
    except Exception as e: print(f"[!] Error: {e}")

def main():
    clear_screen(); print_centered(IP_ART); print(); print()
    check_and_install_deps()
    target = input("Search IP: ").strip()
    if not target: print("\n[!] IP cannot be empty."); input(); return
    print(f"\n[*] Searching for '{target}'...\n")
    get_ip_info(target)
    print("\n"); input("Press ENTER to continue...")

if __name__ == "__main__": main()