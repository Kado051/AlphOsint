import os
import shutil
import requests
import importlib.util
import time

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

CVE_ART = r"""
▄████▄ ██▒   █▓▓█████     ██▓     ▒█████   ▒█████   ██ ▄█▀ █    ██  ██▓███  
▒██▀ ▀█▓██░   █▒▓█   ▀    ▓██▒    ▒██▒  ██▒▒██▒  ██▒ ██▄█▒  ██  ▓██▒▓██░  ██▒
▒▓█    ▄▓██  █▒░▒███      ▒██░    ▒██░  ██▒▒██░  ██▒▓███▄░ ▓██  ▒██░▓██░ ██▓▒
▒▓▓▄ ▄██▒▒██ █░░▒▓█  ▄    ▒██░    ▒██   ██░▒██   ██░▓██ █▄ ▓▓█  ░██░▒██▄█▓▒ ▒
▒ ▓███▀ ░ ▒▀█░  ░▒████▒   ░██████▒░ ████▓▒░░ ████▓▒░▒██▒ █▄▒▒█████▓ ▒██▒ ░  ░
░ ░▒ ▒  ░ ░ ▐░  ░░ ▒░ ░   ░ ▒░▓  ░░ ▒░▒░▒░ ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░▒▓▒ ▒ ▒ ▒▓▒░ ░  ░
  ░  ▒    ░ ░░   ░ ░  ░   ░ ░ ▒  ░  ░ ▒ ▒░   ░ ▒ ▒░ ░ ░▒ ▒░░░▒░ ░ ░ ░▒ ░     
░           ░░     ░        ░ ░   ░ ░ ░ ▒  ░ ░ ░ ▒  ░ ░░ ░  ░░░ ░ ░ ░░       
░ ░          ░     ░  ░       ░  ░    ░ ░      ░ ░  ░  ░      ░              
░           ░
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("requests") is None:
        print("\n[*] requests module not found. Installing...")
        os.system("pip install requests")
        print("[+] Installation complete.\n")

def search_cve(keyword):
    print(f"\n[*] Searching CVE database for '{keyword}'...\n")
    
    # NVD API v2.0 (Resmi ve ücretsizdir, API anahtarı gerektirmez)
    # Sadece kelime bazlı arama yapıyoruz, en son çıkan 10 zafiyeti listeliyoruz.
    url = f"https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={keyword}&resultsPerPage=10"
    
    try:
        r = requests.get(url, timeout=15)
        
        if r.status_code == 200:
            data = r.json()
            vulnerabilities = data.get('vulnerabilities', [])
            
            if not vulnerabilities:
                print("[-] No known CVEs found for this software/version.")
                return
                
            print(f"[+] Found {len(vulnerabilities)} vulnerabilities:\n")
            for item in vulnerabilities:
                cve = item.get('cve', {})
                cve_id = cve.get('id', 'Unknown')
                
                # Açıklamayı al
                descriptions = cve.get('descriptions', [])
                summary = "No description available."
                for desc in descriptions:
                    if desc.get('lang') == 'en':
                        summary = desc.get('value', '')
                        break
                        
                # CVSS Skorunu al (V3 varsa V3, yoksa V2)
                metrics = cve.get('metrics', {})
                cvss_score = "N/A"
                if 'cvssMetricV31' in metrics:
                    cvss_score = metrics['cvssMetricV31'][0]['cvssData']['baseScore']
                elif 'cvssMetricV2' in metrics:
                    cvss_score = metrics['cvssMetricV2'][0]['cvssData']['baseScore']
                
                # Çok uzun açıklamaları kısalt
                if len(summary) > 90:
                    summary = summary[:87] + "..."
                    
                print(f"[+] {cve_id.ljust(15)} | CVSS: {str(cvss_score).ljust(4)} | {summary}")
                
        else:
            print(f"[-] API Error: {r.status_code}")
            print("[-] NVD servers might be busy. Please wait a few seconds and try again.")
    except Exception as e:
        print(f"[!] Network error: {e}")

def main():
    clear_screen()
    print_centered(CVE_ART)
    print()
    print()

    check_and_install_deps()

    target = input("Enter software and version: ").strip()
    
    if not target:
        print("\n[!] Input cannot be empty.")
        input()
        return

    # NVD aramalarında sürüm numarası yerine genellikle yazılım adı daha iyi sonuç verir.
    # Örneğin "apache 2.4.49" yerine "apache" aramak daha çok sonuç döndürür.
    # Biz kullanıcının girdiğini olduğu gibi aratıyoruz.
    search_cve(target)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()