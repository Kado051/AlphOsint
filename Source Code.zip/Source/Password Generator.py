import os
import shutil
import secrets
import string

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

PASS_ART = r"""
 ██▓███   ▄▄▄        ██████   ██████      ▄████ ▓█████  ███▄    █      
▓██░  ██▒▒████▄    ▒██    ▒ ▒██    ▒     ██▒ ▀█▒▓█   ▀  ██ ▀█   █      
▓██░ ██▓▒▒██  ▀█▄  ░ ▓██▄   ░ ▓██▄      ▒██░▄▄▄░▒███   ▓██  ▀█ ██▒     
▒██▄█▓▒ ▒░██▄▄▄▄██   ▒   ██▒  ▒   ██▒   ░▓█  ██▓▒▓█  ▄ ▓██▒  ▐▌██▒     
▒██▒ ░  ░ ▓█   ▓██▒▒██████▒▒▒██████▒▒   ░▒▓███▀▒░▒████▒▒██░   ▓██░ ██▓ 
▒▓▒░ ░  ░ ▒▒   ▓▒█░▒ ▒▓▒ ▒ ░▒ ▒▓▒ ▒ ░    ░▒   ▒ ░░ ▒░ ░░ ▒░   ▒ ▒  ▒▓▒ 
░▒ ░       ▒   ▒▒ ░░ ░▒  ░ ░░ ░▒  ░ ░     ░   ░  ░ ░  ░░ ░░   ░ ▒░ ░▒  
░░         ░   ▒   ░  ░  ░  ░  ░  ░     ░ ░   ░    ░      ░   ░ ░  ░   
               ░  ░      ░        ░           ░    ░  ░         ░   ░  
                                                                    ░
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def generate_password(length):
    characters = string.ascii_letters + string.digits + "!@#$%^&*()_+-=[]{}|;:,.<>?"
    password = ''.join(secrets.choice(characters) for _ in range(length))
    return password

def main():
    clear_screen()
    print_centered(PASS_ART)
    print()
    print()

    try:
        length_input = input("Enter password length: ").strip()
        
        if not length_input.isdigit():
            print("\n[!] Please enter a valid number.")
            input("Press ENTER to continue...")
            return
            
        length = int(length_input)
        
        if length < 8:
            print("\n[!] Password must be at least 8 characters long.")
            input("Press ENTER to continue...")
            return
            
        if length > 256:
            print("\n[!] Password length cannot exceed 256 characters.")
            input("Press ENTER to continue...")
            return
            
        print(f"\n[*] Generating a strong password of {length} characters...\n")
        
        # Sadece tek bir şifre üret ve yazdır
        pwd = generate_password(length)
        print(f"Password: {pwd}")
            
    except KeyboardInterrupt:
        print("\n[!] Process cancelled.")
    except Exception as e:
        print(f"\n[!] Error: {e}")

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()