import os, shutil, urllib.request, json, asyncio, aiohttp

def get_terminal_width(default=80):
    try: return shutil.get_terminal_size().columns
    except Exception: return default

USERNAME_ART = r"""
 █    ██   ██████ ▓█████  ██▀███   ███▄    █  ▄▄▄       ███▄ ▄███▓▓█████ 
 ██  ▓██▒▒██    ▒ ▓█   ▀ ▓██ ▒ ██▒ ██ ▀█   █ ▒████▄    ▓██▒▀█▀ ██▒▓█   ▀ 
▓██  ▒██░░ ▓██▄   ▒███   ▓██ ░▄█ ▒▓██  ▀█ ██▒▒██  ▀█▄  ▓██    ▓██░▒███   
▓▓█  ░██░  ▒   ██▒▒▓█  ▄ ▒██▀▀█▄  ▓██▒  ▐▌██▒░██▄▄▄▄██ ▒██    ▒██ ▒▓█  ▄ 
▒▒█████▓ ▒██████▒▒░▒████▒░██▓ ▒██▒▒██░   ▓██░ ▓█   ▓██▒▒██▒   ░██▒░▒████▒
░▒▓▒ ▒ ▒ ▒ ▒▓▒ ▒ ░░░ ▒░ ░░ ▒▓ ░▒▓░░ ▒░   ▒ ▒  ▒▒   ▓▒█░░ ▒░   ░  ░░░ ▒░ ░
░░▒░ ░ ░ ░ ░▒  ░ ░ ░ ░  ░  ░▒ ░ ▒░░ ░░   ░ ▒░  ▒   ▒▒ ░░  ░      ░ ░ ░  ░
 ░░░ ░ ░ ░  ░  ░     ░     ░░   ░    ░   ░ ░   ░   ▒   ░      ░      ░   
   ░           ░     ░  ░   ░              ░       ░  ░       ░      ░  ░
"""

def print_centered(text, width=None):
    if width is None: width = get_terminal_width()
    for line in text.strip("\n").splitlines(): print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def get_database_path():
    user_profile = os.environ.get("USERPROFILE", os.path.expanduser("~"))
    db_dir = os.path.join(user_profile, "Downloads", "Ultimate Osint Tool AlphA", "Database")
    os.makedirs(db_dir, exist_ok=True)
    return os.path.join(db_dir, "sherlock_data.json")

def check_and_download_db():
    db_path = get_database_path()
    if not os.path.exists(db_path):
        print("\n[*] Downloading Sherlock database...")
        url = "https://raw.githubusercontent.com/sherlock-project/sherlock/master/sherlock_project/resources/data.json"
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                data = json.loads(response.read().decode())
                with open(db_path, 'w', encoding='utf-8') as f: json.dump(data, f, indent=4)
            print("[+] Database downloaded successfully.\n")
        except Exception as e:
            print(f"\n[!] Download failed: {e}"); input("Press ENTER to continue..."); return False
    return True

async def check_site(session, site_name, url_format, username, error_msg=None):
    url = url_format.replace("{}", username).replace("{username}", username)
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
    hidden_sites = ["Instagram", "TikTok", "Twitter", "X", "Facebook", "Reddit", "Tumblr", "Snapchat", "Patreon"]
    try:
        allow_redir = True if site_name in hidden_sites else False
        async with session.get(url, timeout=8, allow_redirects=allow_redir) as response:
            if response.status == 200:
                text = await response.text(); text_lower = text.lower()
                if error_msg and error_msg.lower() in text_lower: return None
                if site_name == "Reddit" and "sorry, nobody on reddit goes by that name" in text_lower: return None
                if site_name in hidden_sites:
                    if "login" in text_lower or "giriş yap" in text_lower or "log in" in text_lower: return site_name, url, True
                    if username.lower() not in text_lower: return site_name, url, True
                return site_name, url, False
            elif response.status in [301, 302, 303, 307, 308]:
                if site_name in hidden_sites: return site_name, url, True
                return None
    except Exception: pass
    return None

async def search_username(username):
    print(f"\n[*] Searching for username '{username}' across multiple sites...\n")
    db_path = get_database_path()
    if not os.path.exists(db_path): return
    with open(db_path, 'r', encoding='utf-8') as f: sites_data = json.load(f)
    
    sites = {}
    for site_name, data in sites_data.items():
        url_format = data.get("url", "") if isinstance(data, dict) else data
        error_msg = data.get("errorMsg") if isinstance(data, dict) else None
        if url_format: sites[site_name] = {"url": url_format, "errorMsg": error_msg}
        
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
    async with aiohttp.ClientSession(headers=headers) as session:
        tasks = [check_site(session, name, data["url"], username, data["errorMsg"]) for name, data in sites.items()]
        results = await asyncio.gather(*tasks)
        found_count, hidden_count = 0, 0
        for result in results:
            if result:
                site, url, is_hidden = result
                site_display = site + "(hidden account)" if is_hidden else site
                print(f"[+] {site_display.ljust(25)} : {url}")
                if is_hidden: hidden_count += 1
                else: found_count += 1
        if found_count == 0 and hidden_count == 0: print("[-] Not found on any tracked site.")
        else: print(f"\n[*] Summary: {found_count} Found, {hidden_count} Hidden | Total: {found_count + hidden_count}")

def main():
    clear_screen(); print_centered(USERNAME_ART); print(); print()
    if not check_and_download_db(): return
    username = input("Search Username: ").strip()
    if not username: print("\n[!] Username cannot be empty."); input(); return
    try: asyncio.run(search_username(username))
    except KeyboardInterrupt: print("\n[!] Process cancelled by user.")
    print("\n"); input("Press ENTER to continue...")

if __name__ == "__main__": main()