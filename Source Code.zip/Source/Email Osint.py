import os, shutil, trio, httpx, importlib.util

def get_terminal_width(default=80):
    try: return shutil.get_terminal_size().columns
    except Exception: return default

EMAIL_ART = r"""
▓█████  ███▄ ▄███▓ ▄▄▄       ██▓ ██▓    
▓█   ▀ ▓██▒▀█▀ ██▒▒████▄    ▓██▒▓██▒    
▒███   ▓██    ▓██░▒██  ▀█▄  ▒██▒▒██░    
▒▓█  ▄ ▒██    ▒██ ░██▄▄▄▄██ ░██░▒██░    
░▒████▒▒██▒   ░██▒ ▓█   ▓██▒░██░░██████▒
░░ ▒░ ░░ ▒░   ░  ░ ▒▒   ▓▒█░░▓  ░ ▒░▓  ░
 ░ ░  ░░  ░      ░  ▒   ▒▒ ░ ▒ ░░ ░ ▒  ░
   ░   ░      ░     ░   ▒    ▒ ░  ░ ░   
   ░  ░       ░         ░  ░ ░      ░  ░
"""

def print_centered(text, width=None):
    if width is None: width = get_terminal_width()
    for line in text.strip("\n").splitlines(): print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_holehe():
    if importlib.util.find_spec("holehe") is None:
        print("\n[*] Holehe module not found. Installing...")
        os.system("pip install holehe")
        print("[+] Installation complete.\n")

async def safe_launch_module(module, email, client, out):
    try: await module(email, client, out)
    except Exception: pass

async def search_email(email):
    print(f"\n[*] Searching for email '{email}' across multiple sites...\n")
    try:
        from holehe.core import import_submodules, get_functions
        modules = import_submodules("holehe.modules")
        websites = get_functions(modules)
        out = []
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
            async with trio.open_nursery() as nursery:
                for website in websites: nursery.start_soon(safe_launch_module, website, email, client, out)
                
        found_count = 0
        for result in out:
            if result.get("exists") is True:
                name = result.get("name", "Unknown")
                domain = result.get("domain", "")
                url = f"https://{domain}" if domain else "Unknown"
                site_display = name
                if result.get("emailrecovery"): site_display += f" (recovery: {result['emailrecovery']})"
                if result.get("phoneNumber"): site_display += f" (phone: {result['phoneNumber']})"
                print(f"[+] {site_display.ljust(30)} : {url}")
                found_count += 1
                
        if found_count == 0: print("[-] Email not found on any tracked site.")
        else: print(f"\n[*] Summary: {found_count} Found")
    except ImportError: print("\n[!] Error: Holehe could not be loaded.")
    except Exception as e: print(f"\n[!] Execution error: {e}")

def main():
    clear_screen(); print_centered(EMAIL_ART); print(); print()
    check_and_install_holehe()
    email = input("Search Email: ").strip()
    if not email: print("\n[!] Email cannot be empty."); input(); return
    try: trio.run(search_email, email)
    except KeyboardInterrupt: print("\n[!] Process cancelled by user.")
    print("\n"); input("Press ENTER to continue...")

if __name__ == "__main__": main()