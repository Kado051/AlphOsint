import os
import shutil
import importlib.util
import base64
import sys

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

DECRYPT_ART = r"""
▓█████▄ ▓█████  ▄████▄   ██▀███ ▓██   ██▓ ██▓███  ▄▄▄█████▓
▒██▀ ██▌▓█   ▀ ▒██▀ ▀█  ▓██ ▒ ██▒▒██  ██▒▓██░  ██▒▓  ██▒ ▓▒
░██   █▌▒███   ▒▓█    ▄ ▓██ ░▄█ ▒ ▒██ ██░▓██░ ██▓▒▒ ▓██░ ▒░
░▓█▄   ▌▒▓█  ▄ ▒▓▓▄ ▄██▒▒██▀▀█▄   ░ ▐██▓░▒██▄█▓▒ ▒░ ▓██▓ ░ 
░▒████▓ ░▒████▒▒ ▓███▀ ░░██▓ ▒██▒ ░ ██▒▓░▒██▒ ░  ░  ▒██▒ ░ 
 ▒▒▓  ▒ ░░ ▒░ ░░ ░▒ ▒  ░░ ▒▓ ░▒▓░  ██▒▒▒ ▒▓▒░ ░  ░  ▒ ░░   
 ░ ▒  ▒  ░ ░  ░  ░  ▒     ░▒ ░ ▒░▓██ ░▒░ ░▒ ░         ░    
 ░ ░  ░    ░   ░          ░░   ░ ▒ ▒ ░░  ░░         ░      
   ░       ░  ░░ ░         ░     ░ ░                       
 ░             ░                 ░ ░
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("cryptography") is None:
        print("\n[*] Cryptography module not found. Installing...")
        os.system("pip install cryptography")
        print("[+] Installation complete.\n")

def get_key(password):
    from cryptography.hazmat.primitives import hashes
    digest = hashes.Hash(hashes.SHA256())
    digest.update(password.encode('utf-8'))
    return base64.urlsafe_b64encode(digest.finalize())

def decrypt_file(file_path, password):
    from cryptography.fernet import Fernet
    try:
        key = get_key(password)
        f = Fernet(key)
        with open(file_path, "rb") as file:
            encrypted_data = file.read()
        decrypted_data = f.decrypt(encrypted_data)
        out_path = file_path[:-4] if file_path.endswith(".enc") else file_path + ".dec"
        with open(out_path, "wb") as file:
            file.write(decrypted_data)
        print(f"\n[+] File decrypted successfully: {out_path}")
    except Exception as e:
        print(f"\n[!] Error decrypting file (Wrong password or corrupted file): {e}")

def main():
    clear_screen()
    print_centered(DECRYPT_ART)
    print()
    print()
    
    check_and_install_deps()
    
    file_path = input("Enter file path: ").strip().strip('"')
    
    if not os.path.exists(file_path):
        print("\n[!] File not found.")
        input("Press ENTER to continue...")
        return
        
    password = input("Enter password: ").strip()
    
    if not password:
        print("\n[!] Password cannot be empty.")
        input("Press ENTER to continue...")
        return

    print("\n[*] Decrypting file...")
    decrypt_file(file_path, password)
        
    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()