import os
import shutil
import importlib.util

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

MAC_ART = r"""
 ███▄ ▄███▓ ▄▄▄       ▄████▄     
▓██▒▀█▀ ██▒▒████▄    ▒██▀ ▀█     
▓██    ▓██░▒██  ▀█▄  ▒▓█    ▄    
▒██    ▒██ ░██▄▄▄▄██ ▒▓▓▄ ▄██▒   
▒██▒   ░██▒ ▓█   ▓██▒▒ ▓███▀ ░   
░ ▒░   ░  ░ ▒▒   ▓▒█░░ ░▒ ▒  ░   
░  ░      ░  ▒   ▒▒ ░  ░  ▒      
░      ░     ░   ▒   ░           
       ░         ░  ░░ ░         
                     ░           
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    # Yerel mac-vendor-lookup kütüphanesini kontrol et, yoksa kur
    if importlib.util.find_spec("mac_vendor_lookup") is None:
        print("\n[*] mac-vendor-lookup module not found. Installing...")
        os.system("pip install mac-vendor-lookup")
        print("[+] Installation complete.\n")

def get_mac_info(mac):
    try:
        from mac_vendor_lookup import MacLookup
        
        print(f"\n[*] Searching for '{mac}'...\n")
        
        # Kütüphaneyi başlat
        mac_lookup = MacLookup()
        
        # Sorguyu yap
        vendor = mac_lookup.lookup(mac)
        
        print(f"[+] MAC Address : {mac}")
        print(f"[+] Vendor      : {vendor}")
        
    except Exception as e:
        print(f"[-] Vendor not found for MAC: {mac}")
        print(f"[!] Error details: {e}")

def main():
    clear_screen()
    print_centered(MAC_ART)
    print()
    print()

    check_and_install_deps()

    mac = input("Search MAC: ").strip()
    
    if not mac:
        print("\n[!] MAC Address cannot be empty.")
        input()
        return

    get_mac_info(mac)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()