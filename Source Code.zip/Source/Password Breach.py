import os
import shutil
import hashlib
import requests
import importlib.util

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

BREACH_ART = r"""
 ██▓███   ▄▄▄        ██████   ██████     ▄▄▄▄    ██▀███  ▓█████ ▄▄▄       ▄████▄   ██░ ██ 
▓██░  ██▒▒████▄    ▒██    ▒ ▒██    ▒    ▓█████▄ ▓██ ▒ ██▒▓█   ▀▒████▄    ▒██▀ ▀█  ▓██░ ██▒
▓██░ ██▓▒▒██  ▀█▄  ░ ▓██▄   ░ ▓██▄      ▒██▒ ▄██▓██ ░▄█ ▒▒███  ▒██  ▀█▄  ▒▓█    ▄ ▒██▀▀██░
▒██▄█▓▒ ▒░██▄▄▄▄██   ▒   ██▒  ▒   ██▒   ▒██░█▀  ▒██▀▀█▄  ▒▓█  ▄░██▄▄▄▄██ ▒▓▓▄ ▄██▒░▓█ ░██ 
▒██▒ ░  ░ ▓█   ▓██▒▒██████▒▒▒██████▒▒   ░▓█  ▀█▓░██▓ ▒██▒░▒████▒▓█   ▓██▒▒ ▓███▀ ░░▓█▒░██▓
▒▓▒░ ░  ░ ▒▒   ▓▒█░▒ ▒▓▒ ▒ ░▒ ▒▓▒ ▒ ░   ░▒▓███▀▒░ ▒▓ ░▒▓░░░ ▒░ ░▒▒   ▓▒█░░ ░▒ ▒  ░ ▒ ░░▒░▒
░▒ ░       ▒   ▒▒ ░░ ░▒  ░ ░░ ░▒  ░ ░   ▒░▒   ░   ░▒ ░ ▒░ ░ ░  ░ ▒   ▒▒ ░  ░  ▒    ▒ ░▒░ ░
░░         ░   ▒   ░  ░  ░  ░  ░  ░      ░    ░   ░░   ░    ░    ░   ▒   ░         ░  ░░ ░
           ░  ░         ░        ░      ░         ░        ░  ░ ░   ░  ░ ░       ░  ░  ░  
                                        ░                               ░                 
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("requests") is None:
        print("\n[*] requests module not found. Installing...")
        os.system("pip install requests")
        print("[+] Installation complete.\n")

def check_password_breach(password):
    # Şifrenin SHA-1 hash'ini al
    sha1_hash = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    prefix = sha1_hash[:5]
    suffix = sha1_hash[5:]
    
    print(f"\n[*] Checking password against HIBP database...\n")
    
    try:
        # K-Anonymity API (Sadece hash'in ilk 5 karakteri gönderilir)
        url = f"https://api.pwnedpasswords.com/range/{prefix}"
        headers = {"User-Agent": "Ultimate-OSINT-Tool"}
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            hashes = response.text.splitlines()
            for h in hashes:
                parts = h.split(":")
                if len(parts) == 2:
                    hash_suffix, count = parts
                    if hash_suffix == suffix:
                        print(f"[!] PASSWORD BREACHED!")
                        print(f"[+] This password has been exposed {count} times in data breaches.")
                        print(f"[+] You should change it immediately.")
                        return
            
            print("[-] Good news! This password was not found in any known data breaches.")
        else:
            print(f"[-] API Error: {response.status_code}")
    except Exception as e:
        print(f"[!] Network error: {e}")

def main():
    clear_screen()
    print_centered(BREACH_ART)
    print()
    print()

    check_and_install_deps()

    # getpass kaldırıldı, şifre ekranda görünecek
    password = input("Enter password to check: ")
    
    if not password:
        print("\n[!] Password cannot be empty.")
        input("Press ENTER to continue...")
        return

    check_password_breach(password)

    print("\n")
    input("Press ENTER to continue...")
    return

    check_password_breach(password)

    print("\n")
    input("Press ENTER to continue...")

if __name__ == "__main__":
    main()