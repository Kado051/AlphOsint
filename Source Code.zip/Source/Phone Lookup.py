import os, shutil, importlib.util

def get_terminal_width(default=80):
    try: return shutil.get_terminal_size().columns
    except Exception: return default

PHONE_ART = r"""
 ██▓███   ██░ ██  ▒█████   ███▄    █ ▓█████ 
▓██░  ██▒▓██░ ██▒▒██▒  ██▒ ██ ▀█   █ ▓█   ▀ 
▓██░ ██▓▒▒██▀▀██░▒██░  ██▒▓██  ▀█ ██▒▒███   
▒██▄█▓▒ ▒░▓█ ░██ ▒██   ██░▓██▒  ▐▌██▒▒▓█  ▄ 
▒██▒ ░  ░░▓█▒░██▓░ ████▓▒░▒██░   ▓██░░▒████▒
▒▓▒░ ░  ░ ▒ ░░▒░▒░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ░░ ▒░ ░
░▒ ░      ▒ ░▒░ ░  ░ ▒ ▒░ ░ ░░   ░ ▒░ ░ ░  ░
░░        ░  ░░ ░░ ░ ░ ▒     ░   ░ ░    ░   
          ░  ░  ░    ░ ░           ░    ░  ░
"""

def print_centered(text, width=None):
    if width is None: width = get_terminal_width()
    for line in text.strip("\n").splitlines(): print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def check_and_install_deps():
    if importlib.util.find_spec("phonenumbers") is None: os.system("pip install phonenumbers")

def get_phone_info(phone_str):
    try:
        import phonenumbers
        from phonenumbers import geocoder, carrier, timezone
        clean_phone = phone_str.replace(" ", "").replace("-", "")
        try: parsed_number = phonenumbers.parse(clean_phone, None)
        except: parsed_number = phonenumbers.parse(clean_phone, "TR")
            
        is_valid = phonenumbers.is_valid_number(parsed_number)
        print(f"[+] Input          : {phone_str}")
        print(f"[+] Valid          : {is_valid}")
        
        if is_valid:
            region = geocoder.description_for_number(parsed_number, "en")
            print(f"[+] Region         : {region if region else 'Unknown'}")
            operator = carrier.name_for_number(parsed_number, "en")
            print(f"[+] Carrier        : {operator if operator else 'Unknown'}")
            number_type = phonenumbers.number_type(parsed_number)
            type_map = {0: "Fixed Line", 1: "Mobile", 2: "Fixed Line or Mobile", 3: "Toll Free", 4: "Premium Rate", 5: "Shared Cost", 6: "VoIP", 7: "Personal Number", 8: "Pager", 9: "Universal Access", 10: "Voicemail"}
            print(f"[+] Line Type      : {type_map.get(number_type, 'Unknown')}")
            tz = timezone.time_zones_for_number(parsed_number)
            if tz: print(f"[+] Timezone       : {', '.join(tz)}")
            print(f"[+] Intl Format    : {phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}")
        else: print("[-] This phone number is not valid.")
    except Exception as e: print(f"[!] Error parsing phone number: {e}")

def main():
    clear_screen(); print_centered(PHONE_ART); print(); print()
    check_and_install_deps()
    phone = input("Search Phone: ").strip()
    if not phone: print("\n[!] Phone number cannot be empty."); input(); return
    print(f"\n[*] Searching for '{phone}'...\n")
    get_phone_info(phone)
    print("\n"); input("Press ENTER to continue...")

if __name__ == "__main__": main()