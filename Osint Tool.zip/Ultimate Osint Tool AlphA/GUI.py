import ctypes
import sys
import os
import shutil

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

def relaunch_as_admin():
    script = os.path.abspath(sys.argv[0])
    cmd_command = f'/k python "{script}"'
    
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", cmd_command, None, 1)
    if ret <= 32:
        print(f"[!] UAC elevation failed (code: {ret})")
        return False
    return True

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default

ALPHA_ART = r"""
 ▄▄▄       ██▓     ██▓███   ██░ ██  ▒█████    ██████  ██▓ ███▄    █ ▄▄▄█████▓
▒████▄    ▓██▒    ▓██░  ██▒▓██░ ██▒▒██▒  ██▒▒██    ▒ ▓██▒ ██ ▀█   █ ▓  ██▒ ▓▒
▒██  ▀█▄  ▒██░    ▓██░ ██▓▒▒██▀▀██░▒██░  ██▒░ ▓██▄   ▒██▒▓██  ▀█ ██▒▒ ▓██░ ▒░
░██▄▄▄▄██ ▒██░    ▒██▄█▓▒ ▒░▓█ ░██ ▒██   ██░  ▒   ██▒░██░▓██▒  ▐▌██▒░ ▓██▓ ░ 
 ▓█   ▓██▒░██████▒▒██▒ ░  ░░▓█▒░██▓░ ████▓▒░▒██████▒▒░██░▒██░   ▓██░  ▒██▒ ░ 
 ▒▒   ▓▒█░░ ▒░▓  ░▒▓▒░ ░  ░ ▒ ░░▒░▒░ ▒░▒░▒░ ▒ ▒▓▒ ▒ ░░▓  ░ ▒░   ▒ ▒   ▒ ░░   
  ▒   ▒▒ ░░ ░ ▒  ░░▒ ░      ▒ ░▒░ ░  ░ ▒ ▒░ ░ ░▒  ░ ░ ▒ ░░ ░░   ░ ▒░    ░    
  ░   ▒     ░ ░   ░░        ░  ░░ ░░ ░ ░ ▒  ░  ░  ░   ▒ ░   ░   ░ ░   ░      
      ░  ░    ░  ░          ░  ░  ░    ░ ░        ░   ░           ░          
"""

def print_centered(text, width=None):
    if width is None:
        width = get_terminal_width()
    for line in text.strip("\n").splitlines():
        print(line.center(width))

def clear_screen():
    os.system("chcp 65001 >nul")
    os.system("cls")

def run_module(module_name):
    user_profile = os.environ.get("USERPROFILE", os.path.expanduser("~"))
    target_dir = os.path.join(user_profile, "Downloads", "Ultimate Osint Tool AlphA", "Database")
    target_file = os.path.join(target_dir, module_name)
    
    if not os.path.exists(target_file):
        print(f"\n[!] Error: File not found -> {target_file}")
        input("\nPress ENTER to continue...")
        return False

    clear_screen()
    
    try:
        sys.path.insert(0, target_dir)
        with open(target_file, "r", encoding="utf-8") as f:
            code = f.read()
        exec(code, {"__name__": "__main__", "__file__": target_file})
    except Exception as e:
        print(f"\n[!] Execution error: {e}")
        input("\nPress ENTER to continue...")
        return False

    return True

def main():
    while True:
        clear_screen()
        print_centered(ALPHA_ART)
        print()
        print()
        
        # [20] Header Analyze olarak güncellendi
        print("[1] Username Search     [6] Domain Lookup      [11] File Encrypt    [16] EXIF Check     [21] Discord Server")
        print("[2] Email Search        [7] DNS Lookup         [12] File Decrypt    [17] Hash Decoder   [22] Discord Name")
        print("[3] IP Search           [8] MAC Scanner        [13] Pass Generator  [18] SSL Lookup     [23] YouTube Acc")
        print("[4] IP Pinger           [9] Subdomain Scanner  [14] Pass Breach     [19] CVE Lookup     [24] GitHub Acc")
        print("[5] Phone Lookup        [10] Port Scanner      [15] Dox EXIF        [20] Header Analyze [25] Tool Info")
        print()
        
        choice = input("your choice: ").strip()
        
        if choice == "1": run_module("Username Osint.py")
        elif choice == "2": run_module("Email Osint.py")
        elif choice == "3": run_module("IP Search.py")
        elif choice == "4": run_module("IP Pinger.py")
        elif choice == "5": run_module("Phone Lookup.py")
        elif choice == "6": run_module("Domain Lookup.py")
        elif choice == "7": run_module("DNS Lookup.py")
        elif choice == "8": run_module("MAC Lookup.py")
        elif choice == "9": run_module("Subdomain Scanner.py")
        elif choice == "10": run_module("Port Scanner.py")
        elif choice == "11": run_module("File Encrypt.py")
        elif choice == "12": run_module("File Decrypt.py")
        elif choice == "13": run_module("Password Generator.py")
        elif choice == "14": run_module("Password Breach.py")
        elif choice == "15": run_module("Dox EXIF.py")
        elif choice == "16": run_module("EXIF Check.py")
        elif choice == "17": run_module("Hash Decoder.py")
        elif choice == "18": run_module("SSL Lookup.py")
        elif choice == "19": run_module("CVE Lookup.py")
        elif choice == "20": run_module("Header Analyzer.py") # Dosya adı aynı kaldı
        
        elif choice == "21":
            print("\n[*] Discord Server: https://discord.gg/8panN8han")
            input("\nPress ENTER to continue...")
        elif choice == "22":
            print("\n[*] Discord Name: kadoonoone123")
            input("\nPress ENTER to continue...")
        elif choice == "23":
            print("\n[*] YouTube Acc: https://www.youtube.com/@AlphADC-1")
            input("\nPress ENTER to continue...")
        elif choice == "24":
            print("\n[*] GitHub Acc: https://github.com/Kado051")
            input("\nPress ENTER to continue...")
        elif choice == "25":
            clear_screen()
            print_centered(ALPHA_ART)
            print()
            print()
            print("Tool Info:")
            print("Made by AlphA")
            input("\nPress ENTER to continue...")
            
        else:
            print("\n[!] Invalid choice.")
            input("Press ENTER to continue...")

if __name__ == "__main__":
    if not is_admin():
        print("[*] Not running as admin, elevating via UAC...")
        if relaunch_as_admin():
            sys.exit(0)
        else:
            sys.exit(1)

    main()